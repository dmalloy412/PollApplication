# run this file and allow user to make a new poll
from models.base import *
from models.poll import Poll
from models.answers import Answer
from models.responses import *

def y_or_n_check(answer):
    if answer == "Y":
        return True   
    elif answer == "N":
        return False
    else:
        print("Invalid input, please type 'Y' or 'N'")
        return False

def main():
    session = init_db_session()
    print("Type in 'Q' at any time to quit")
    user = input("Do you want to create a new poll? ")
    while user.upper() != 'Q':
        #if yes, also will throw an error if you say anything else:
        if user.upper() == 'Y':
            # Query existing polls to find last id
            poll_id = int(0 if session.query(func.max(Poll.id)).all()[0][0] is None else session.query(func.max(Poll.id)).all()[0][0]+1)
            new_poll = Poll(id=poll_id)
            # Get question string
            raw_question = input("What is your question? ")
            last_char = raw_question[-1]
            if last_char != "?":
                raw_question = raw_question + "?"
            new_poll.question = raw_question
            user = input("Is this a yes or no question? ")
            if user.upper() == 'Y':
                option1 = Answer(answer="[1] Yes",poll=new_poll, poll_id=poll_id)
                response1 = Response(response_count=0, answer=option1, answer_id=option1.id,poll=new_poll,poll_id=poll_id)
                option2 = Answer(answer="[2] No", poll=new_poll, poll_id=poll_id)
                response2 = Response(response_count=0, answer=option2, answer_id=option2.id,poll=new_poll,poll_id=poll_id)
                session.add(new_poll)
            elif user.upper() == 'N':
                num_answers = str(input("How many answers? "))
                # Test if user entered a number
                if not num_answers.isnumeric():
                    print("Invalid input, please enter an integer")
                    continue
                for i in range(1,int(num_answers)+1):
                    n = input("Answer: ")
                    new_answer = Answer(answer = f"[{i}] {n}",poll=new_poll, poll_id=poll_id)
                    new_response = Response(response_count=0,answer=new_answer,answer_id=new_answer.id,poll=new_poll,poll_id=poll_id)
                session.add(new_poll)
            else:
                print("Invalid input, please type either 'Y' or 'N'")
        elif user.upper() == 'N':
            print("Goodbye")
            session.commit()
            return
        else:
            print("Invalid input, please type 'Y' or 'N'")
        # Get user input again
        print("Type in 'Q' at any time to quit")
        user = input("Do you want to create a new poll? ")
    session.commit()
    # Once it gets to this point a valid Poll object has been constructed


if __name__ == '__main__':
    main()