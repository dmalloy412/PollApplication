from models.base import *

class Poll(Base):
    __tablename__ = "polls"
    id = Column(Integer, primary_key=True)
    question = Column(String)

    def __repr__(self):
        return f"{self.question}"