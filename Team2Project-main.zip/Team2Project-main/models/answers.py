from models.base import *
from models.poll import Poll

class Answer(Base):

    __tablename__ = 'answers'
    id = Column(Integer, primary_key=True)
    answer = Column(String)

    poll_id = Column(Integer, ForeignKey('polls.id'))
    poll = relationship(Poll, backref=backref('answers', uselist=True, cascade='delete,all'))

    def __repr__(self):
        return f"{self.answer}"


