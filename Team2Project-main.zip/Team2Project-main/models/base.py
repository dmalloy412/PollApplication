import sqlalchemy.orm as s
from sqlalchemy import Column, DateTime, String, Integer, ForeignKey, func
from sqlalchemy.orm import relationship, backref
#import sqlalchemy.orm as s
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()

# The main objective of the ORM API of SQLAlchemy is
# to facilitate associating user-defined Python classes with database tables,
# and objects of those classes with rows in their corresponding tables.

# this method will be called at the beginning of tests to setup a db in memory
def init_db_session():
    print("Init_db")
    session = s.sessionmaker()
    # setup db in memory, not a file
    engine = create_engine('sqlite:///polls.sqlite')
    session.configure(bind=engine)

    # column = Column('response_count', Integer, primary_key=False)
    # column_name = column.compile(dialect=engine.dialect)
    # column_type = column.type.compile(engine.dialect)
    # engine.execute('ALTER TABLE responses ADD COLUMN %s %s' % (column_name, column_type))

    # create all the tables
    Base.metadata.create_all(engine)

    # when you call this it will return the session to use to commit changes
    return session()

# you can use this to close it but not really necessary
def end_db_session(session):
    session.close()


