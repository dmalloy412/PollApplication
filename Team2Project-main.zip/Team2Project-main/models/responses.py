from models.base import *
from models.answers import Answer
from models.poll import Poll

class Response(Base):
    __tablename__ = 'responses'
    id = Column(Integer, primary_key=True)
    response_count = Column(Integer)
    # keeps track of which poll response is for
    poll_id = Column(Integer, ForeignKey('polls.id'))
    poll = relationship(Poll, backref=backref('responses', uselist=True, cascade='delete,all'))
    answer_id = Column(Integer, ForeignKey('answers.id'))
    answer = relationship(Answer, backref=backref('responses', uselist=True, cascade='delete,all'))
    def __repr__(self):
        return f"{self.poll}: {self.answer}: {self.response_count} votes"
    def get_percentages(self,answer):

        # total_responses = 0
        # for res in responses:
        #     total_responses += int(0 if res.response_count is None else res.response_count)
        #     print(total_responses)
        # for res in responses:
        #     ratio = int(0 if res.response_count is None else res.response_count)/total_responses
        #     print(f"{res.answer}{'':<15}{ratio*100:.2f}%")
         return
# current_count = session.query(Response).filter_by(Response.poll_id == poll_id, Response.answer_id==answer_id).update(dict(response_count=Response.response_count+1))
# update(user_table).where(user_table.c.id == 5).values(name='user #5')

# current_count = int(0 if current_count is None else current_count)
# Response.response_count = int(0 if Response.response_count is None else Response.response_count) +1)
# session.add()
# stmt = (
#     update(user_table).
#     where(user_table.c.id == 5).
#     values(name='user #5')
# )
# Display percentages
    # total_responses = 0
    # for res in responses:
    #     total_responses += int(0 if res.response_count is None else res.response_count)
    #     print(total_responses)
    # for res in responses:
    #     ratio = int(0 if res.response_count is None else res.response_count)/total_responses
    #     print(f"{res.answer}{'':<15}{ratio*100:.2f}%")
