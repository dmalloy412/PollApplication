# run this file so users can respond to a poll
from sqlalchemy import update
from models.base import *
from models.poll import *
from models.answers import *
from models.responses import *

def main():
    session = init_db_session()
    # session.query(Poll).delete()
    # session.query(Response).delete()
    # session.query(Answer).delete()
    # session.commit()

    questions = session.query(Poll).all()
    answers = session.query(Answer).all()
    responses = session.query(Response).all()
    #print(responses)
    # If no polls end program
    if not len(questions):
        print("No polls currently exist")
        return

    for i, q in enumerate(questions):
        print(f"[{i+1}] {q}")

    # might have to bold the numbers

    choice = int(input("Which question would you like to answer? "))

    # Query answers matching poll_id
    current_q = questions[choice-1]
    poll_id = current_q.id
    query = session.query(Answer).filter(Answer.poll_id == poll_id)
    answer_count = 0
    for answer in query:
        answer_count += 1
        print(answer)

    # Check if user input is numeric
    response = str(input("Select your answer by typing the corresponding number: "))
    if not response.isnumeric():
        print("Invalid input, please retake poll and enter a valid integer")
        return
    elif int(response) < 1 or int(response) > answer_count:
        print("Invalid number entered, please retake poll and enter valid integer")
        return
    #current_answer = current_q.answers[int(response)-1]
    current_q_responses = []
    #wanna get the responses associated with the question
    for r in responses:
        if r.poll.question == current_q.question:
            current_q_responses.append(r)
    current_r = current_q_responses[int(response)-1]
    current_r.response_count += 1
    session.add(current_r)
    session.commit()
    #print(current_q_responses)

    print(current_q.question)
    # Display percentages
    total_responses = 0
    for res in current_q_responses:
        total_responses += int(0 if res.response_count is None else res.response_count)
    for res in current_q_responses:
        ratio = int(0 if res.response_count is None else res.response_count) / total_responses
        print(f"{res.answer}{'':<15}{ratio * 100:.2f}%")
    print("Thank you for your response")


if __name__ == '__main__':
    main()