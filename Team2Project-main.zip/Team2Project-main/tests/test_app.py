import pytest
from models.base import *
from models.answers import *
from models.poll import *
from models.responses import *

class TestPoll:

    def test_db(self):
        ses = init_db_session()
    #
    #     assert ses.query(Poll).count() == 0
    #
    #     question = Question()
    #     q = Question(name='question', poll=poll)
    #     ses.add(q)
    #     ses.commit()
    #
    #     assert ses.query(Poll).count() == 1
    #     assert ses.query(Question).count() == 1

    def test_valid_for_name_is_none(self):
        pass

    def test_valid_question(self):
        p = Poll()
        p.question = "cats or dogs?"

        assert p.question == "cats or dogs?"


    def test_question_has_characters(self):
        p = Poll()
        invalid_names = ["12345", "      ", "🥉🦢"]
        for name in invalid_names:
            # jarp: Question is not a class,  you are using Poll
            p = Poll(question = name)
            assert p.question != False


    def test_question_mark(self):
        p = Poll()
        # jarp: this is causing a problem because you need tests to be automated
        # so instead of using input, just set the string
        str = ("What is the weather")
        last_char = str[-1]
        if last_char != "?":
            print("question mark?")
            str = str + "?"
        print(str)
        p.question = str
        "why?"
        assert p.question[-1]=="?"

    # def test_percentages(self):
    #     #create a poll
    #     #create 2 answers for the poll
    #     #create 3 responses, 2 for one poll and 1 for the other poll
