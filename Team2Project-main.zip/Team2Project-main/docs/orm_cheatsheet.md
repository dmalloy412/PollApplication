# ORM Imports and Functions

## packages needed for ORM
- sqlalchemy (orm engine)
- pysqlite3 | pychopg | ... (database adapter)

## Building your Classes with ORM
To build in a connection with a db, import the db related modules
- `from sqlalchemy import Column, DateTime, String, Integer, ForeignKey, func`

To build associations between tables, import relationship and backref

- `from sqlalchemy.orm import relationship, backref`

To have Classes inherit all the ORM goodies, use declarative base
- `from sqlalchemy.ext.declarative import declarative_base`
- `Base = declarative_base()`

### Modeling Databases
- Attributes
  - `id = Column(Integer, primary_key=True`)
  - `attribute = Column(String`)
  - `attribute = Column(DateTime)`

- Associations
  - `family_id = Column(Integer, ForeignKey('families.id'))`
  - `family = relationship(Family, backref=backref('members', uselist=True, cascade='delete,all'))`

## Using your classes to interact with a data base

Set up a session to use with a database
- `from sqlalchemy.orm import sessionmaker`
- `session = sessionmaker()`

Import the 'create_engine' module 
- `from sqlalchemy import create_engine`

configure and create the connection
- `engine = create_engine('sqlite:///db/family.sqlite')`
- `session.configure(bind=engine)`

Generate all database tables from your Class definitions
- `Base.metadata.create_all(engine)`

Open a session to actually do the activity
- `session = session()`

Code to save to the database
- `family = Family(...)`
- `session.add(family)`
- `session.commit()`

close database session
- `session.close()`
