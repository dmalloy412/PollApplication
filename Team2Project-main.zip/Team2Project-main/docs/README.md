# Team2Project

## Overview Requirements

Must contain at least 3 classes.

Must implement Inheritance, composition and/or polymorphism.

Must store and retrieve data from a database. 

When you run it repeatedly, the older poll question are options to select and the older responses are also saved.

Must validate inputs and handle at least one expected error

Must have a test suite verifying that the application’s objects behave as expected.
## Specific Requirements and Use Case Examples

A CLI application that allows users to create poll questions with predetermined answers (either text or yes/no). Once created users can select a question and respond to it. The CLI will store the responses and the user then can find out how everyone responded by percentages.
## Add new poll
- Do you want to create a new poll? (response: Y/N)
- What is your question? “How much wood could…”
- Is this a Yes or No question? (responses: Y/N)
- How many answers? (int)
- Loop through and prompt for the answers

## Answer poll 
List questions with integers, user enters the number for the poll to answer

    [1] What is the best thing ever?
    [2] How much wood could a woodchuck…?

Lists answers also with numbers, enter the number to respond to the question

	How much wood could a woodchuck…?
	
	[1] A lot.
	[2] None
	[3] I don’t know
## See results

Once the poll is responded to, display the answers with their percentages

How much wood could a woodchuck…?
	
	A lot.  (25%)
	None (50%)
	I don’t know (25%)

## Additional Requirements 
- Require ‘?’ at the end of questions (or add it if missing)
- Answers can be variable (Must be at least two responses, but can be more)
- Ask whether it is a yes/no answer and in that case don’t ask for responses, just use Yes and No
